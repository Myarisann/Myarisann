-- ================================================================
-- ArisanChan — Skema Database Supabase
-- Jalankan file ini di Supabase SQL Editor (Project > SQL Editor)
-- ================================================================

-- extension buat uuid
create extension if not exists "pgcrypto";

-- ----------------------------------------------------------------
-- 1. USERS  (profil tambahan di atas Supabase Auth, tanpa data sensitif)
-- ----------------------------------------------------------------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nama text not null,
  no_hp text unique not null,
  qr_pembayaran_url text,      -- link gambar QR e-wallet pribadi (Supabase Storage)
  created_at timestamptz default now()
);

-- ----------------------------------------------------------------
-- 2. GROUPS
-- ----------------------------------------------------------------
create table public.groups (
  id uuid primary key default gen_random_uuid(),
  nama_grup text not null,
  nominal_setoran numeric not null check (nominal_setoran > 0),
  periode text not null check (periode in ('mingguan', 'bulanan')),
  admin_id uuid references public.profiles(id) not null,
  invite_code text unique not null default substr(md5(random()::text), 1, 8),
  periode_berjalan int not null default 1,
  status text not null default 'aktif' check (status in ('aktif', 'selesai')),
  created_at timestamptz default now()
);

-- ----------------------------------------------------------------
-- 3. GROUP MEMBERS (anggota + urutan giliran)
-- ----------------------------------------------------------------
create table public.group_members (
  id uuid primary key default gen_random_uuid(),
  group_id uuid references public.groups(id) on delete cascade not null,
  user_id uuid references public.profiles(id) not null,
  urutan_giliran int not null,
  sudah_narik boolean default false,
  joined_at timestamptz default now(),
  unique (group_id, user_id),
  unique (group_id, urutan_giliran)
);

-- ----------------------------------------------------------------
-- 4. SETORAN (per anggota per periode)
-- ----------------------------------------------------------------
create table public.setoran (
  id uuid primary key default gen_random_uuid(),
  group_id uuid references public.groups(id) on delete cascade not null,
  user_id uuid references public.profiles(id) not null,
  periode_ke int not null,
  status text not null default 'menunggu' check (status in ('menunggu', 'menunggu_konfirmasi', 'lunas')),
  bukti_transfer_url text,
  dikonfirmasi_oleh uuid references public.profiles(id),
  created_at timestamptz default now(),
  confirmed_at timestamptz,
  unique (group_id, user_id, periode_ke)
);

-- ----------------------------------------------------------------
-- 5. PENARIKAN (log siapa yang narik tiap periode)
-- ----------------------------------------------------------------
create table public.penarikan (
  id uuid primary key default gen_random_uuid(),
  group_id uuid references public.groups(id) on delete cascade not null,
  user_id uuid references public.profiles(id) not null,
  periode_ke int not null,
  total_diterima numeric not null,
  created_at timestamptz default now(),
  unique (group_id, periode_ke)
);

-- ================================================================
-- FUNGSI: cek & proses penarikan (validasi inti keamanan giliran)
-- Dipanggil dari Edge Function, BUKAN langsung dari client.
-- ================================================================
create or replace function public.proses_penarikan(p_group_id uuid)
returns jsonb
language plpgsql
security definer
as $$
declare
  v_group record;
  v_giliran record;
  v_total_anggota int;
  v_total_lunas int;
  v_total_dana numeric;
  p_user_id uuid := auth.uid();  -- diambil dari sesi login, TIDAK bisa dispoof client
begin
  if p_user_id is null then
    return jsonb_build_object('sukses', false, 'alasan', 'Kamu belum login');
  end if;

  select * into v_group from public.groups where id = p_group_id;
  if not found then
    return jsonb_build_object('sukses', false, 'alasan', 'Grup tidak ditemukan');
  end if;

  select * into v_giliran from public.group_members
    where group_id = p_group_id and urutan_giliran = v_group.periode_berjalan;

  if v_giliran.user_id != p_user_id then
    return jsonb_build_object('sukses', false, 'alasan', 'Bukan giliran kamu');
  end if;

  select count(*) into v_total_anggota from public.group_members where group_id = p_group_id;
  select count(*) into v_total_lunas from public.setoran
    where group_id = p_group_id and periode_ke = v_group.periode_berjalan and status = 'lunas';

  if v_total_lunas < v_total_anggota then
    return jsonb_build_object('sukses', false, 'alasan', 'Masih ada anggota yang belum lunas setor');
  end if;

  v_total_dana := v_group.nominal_setoran * v_total_anggota;

  insert into public.penarikan (group_id, user_id, periode_ke, total_diterima)
  values (p_group_id, p_user_id, v_group.periode_berjalan, v_total_dana);

  update public.group_members set sudah_narik = true
    where group_id = p_group_id and user_id = p_user_id;

  update public.groups set periode_berjalan = periode_berjalan + 1
    where id = p_group_id;

  return jsonb_build_object('sukses', true, 'total_diterima', v_total_dana);
end;
$$;

-- ================================================================
-- ROW LEVEL SECURITY — hanya anggota grup yang bisa lihat data grupnya
-- ================================================================
alter table public.profiles enable row level security;
alter table public.groups enable row level security;
alter table public.group_members enable row level security;
alter table public.setoran enable row level security;
alter table public.penarikan enable row level security;

create policy "profil sendiri bisa dibaca semua yg login" on public.profiles
  for select using (auth.role() = 'authenticated');
create policy "user cuma bisa update profil sendiri" on public.profiles
  for update using (auth.uid() = id);
create policy "user bisa insert profil sendiri" on public.profiles
  for insert with check (auth.uid() = id);

create policy "anggota grup bisa lihat grupnya" on public.groups
  for select using (
    exists (select 1 from public.group_members gm where gm.group_id = id and gm.user_id = auth.uid())
  );
create policy "user bisa bikin grup" on public.groups
  for insert with check (auth.uid() = admin_id);

create policy "anggota grup bisa lihat member lain di grup yg sama" on public.group_members
  for select using (
    exists (select 1 from public.group_members gm2 where gm2.group_id = group_id and gm2.user_id = auth.uid())
  );
create policy "user bisa join grup (insert diri sendiri)" on public.group_members
  for insert with check (auth.uid() = user_id);

create policy "anggota grup bisa lihat semua setoran di grupnya" on public.setoran
  for select using (
    exists (select 1 from public.group_members gm where gm.group_id = group_id and gm.user_id = auth.uid())
  );
create policy "user bisa insert setoran sendiri" on public.setoran
  for insert with check (auth.uid() = user_id);
create policy "anggota grup bisa update status setoran (konfirmasi)" on public.setoran
  for update using (
    exists (select 1 from public.group_members gm where gm.group_id = group_id and gm.user_id = auth.uid())
  );

create policy "anggota grup bisa lihat riwayat penarikan" on public.penarikan
  for select using (
    exists (select 1 from public.group_members gm where gm.group_id = group_id and gm.user_id = auth.uid())
  );

-- ================================================================
-- REALTIME — supaya update setoran/giliran langsung ke semua anggota
-- ================================================================
alter publication supabase_realtime add table public.setoran;
alter publication supabase_realtime add table public.group_members;
alter publication supabase_realtime add table public.groups;
alter publication supabase_realtime add table public.penarikan;
