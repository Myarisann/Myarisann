# ArisanChan 🌸

Aplikasi arisan digital (tabungan bersama sistem giliran) — gratis 100%, tanpa KTP,
setoran pakai QR e-wallet pribadi tiap anggota.

## Cara Setup

### 1. Bikin project Supabase (gratis)
1. Buka [supabase.com](https://supabase.com) → New Project
2. Buka **SQL Editor** → paste isi file `supabase/schema.sql` → Run
3. Buka **Storage** → bikin 2 bucket, keduanya **public**:
   - `qr-pembayaran` (buat nyimpen QR e-wallet tiap user)
   - `bukti-transfer` (buat nyimpen screenshot bukti setor)
4. Buka **Project Settings → API** → salin `Project URL` dan `anon public key`

### 2. Setup environment
```bash
cp .env.local.example .env.local
# lalu isi NEXT_PUBLIC_SUPABASE_URL dan NEXT_PUBLIC_SUPABASE_ANON_KEY
```

### 3. Jalanin lokal
```bash
npm install
npm run dev
```
Buka `http://localhost:3000`

### 4. Push ke GitHub
```bash
git init
git add .
git commit -m "init: ArisanChan"
git branch -M main
git remote add origin https://github.com/USERNAME/arisanchan.git
git push -u origin main
```

### 5. Deploy ke Vercel (gratis)
1. Buka [vercel.com](https://vercel.com) → New Project → import repo GitHub kamu
2. Di tab Environment Variables, isi `NEXT_PUBLIC_SUPABASE_URL` & `NEXT_PUBLIC_SUPABASE_ANON_KEY`
3. Deploy — beres, aplikasi live dan bisa diakses dari HP mana pun

## Alur Pakai
1. Daftar pakai nama + no HP + PIN 6 digit (gak ada KTP)
2. Upload QR e-wallet pribadi kamu (DANA/OVO/GoPay dll) di halaman `/onboarding`
3. Buat grup arisan baru, atau join pakai kode undangan dari temen
4. Tiap periode: anggota yang giliran narik → QR-nya otomatis ditampilkan ke semua anggota
5. Anggota transfer manual via QR itu → tandai "Sudah Transfer" → upload bukti
6. Yang giliran (atau anggota lain) konfirmasi bukti → status jadi "Lunas"
7. Kalau semua anggota udah lunas & udah masuk waktunya → tombol "Tarik Dana" otomatis aktif
   buat yang giliran doang (divalidasi di database, bukan cuma di UI)
8. Setelah ditarik, giliran otomatis geser ke anggota berikutnya

## Kenapa gratis selamanya
Gak ada payment gateway (Xendit dkk) — transfer terjadi langsung antar e-wallet pribadi
anggota di luar aplikasi. Aplikasi cuma jadi "pencatat + pengunci giliran", jadi:
- Next.js di Vercel → gratis
- Database + Auth + Storage + Realtime di Supabase → gratis (free tier)
- Gak ada biaya transaksi sama sekali

## Batasan yang perlu disadari
- Konfirmasi setoran itu manual (lihat bukti transfer), bukan deteksi otomatis kayak
  payment gateway — jadi tetap saling percaya antar anggota grup
- Cocok buat circle kecil/private, bukan aplikasi publik skala besar (kalau mau publik,
  perlu pertimbangkan izin penyelenggara pembayaran)
